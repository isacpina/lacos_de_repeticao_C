#include <stdio.h>

int main()
{
   int vetor[5] = {5,4,3,2,1};
   int i;
   
   for(i = 0; i < 5; i++){
       printf("Número %d\n", vetor[i]);
   }
   
   
}