#include <stdio.h>

int main()
{
    int valor = 5, resultado = 1;
    
    
    while( valor >= 1 ){
        
        printf("%i\n", resultado = resultado * valor);
        valor--;
       
        
    }
    
    
}
